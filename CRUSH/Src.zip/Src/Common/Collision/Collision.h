#pragma once
#include <DxLib.h>

namespace Collision3D
{
    // ���̓��m�̏Փ˔���
    bool HitSpheres(const VECTOR& a, float ar, const VECTOR& b, float br);
    
    // ���̂ƃJ�v�Z���̏Փ˔���
    bool HitSphereCapsule(
        const VECTOR& sphPos, float sphRadius,
        const VECTOR& capA, const VECTOR& capB, float capRadius);
}

namespace Collision2D
{
    // ��`�Ɠ_�̏Փ˔���
    bool HitPointRect(
        int x, int y, const RECT& rect);
}

namespace CollisionXZ
{
    /// <summary>
    /// �l�p�Ɖ~�̔���
    /// </summary>
    /// <param name="origin">�l�p�̎�O�̕ӂ̐^��</param>
    /// <param name="forward">�O����</param>
    /// <param name="length"></param>
    /// <param name="width"></param>
    /// <param name="target"></param>
    /// <param name="targetRadius"></param>
    /// <returns></returns>
    bool HitRectCircle(
        const VECTOR& origin, const VECTOR& forward, float length, float width,
        const VECTOR& target, float targetRadius);

    /// <summary>
    /// ��Ɖ~�̔���
    /// </summary>
    /// <param name="origin">��̍���</param>
    /// <param name="forward">��̐^�񒆂̌���</param>
    /// <param name="radius">��̔��a</param>
    /// <param name="halfAngleRad">�^�񒆂���[�܂ł̊p�x</param>
    /// <param name="target"></param>
    /// <param name="targetRadius"></param>
    /// <returns></returns>
    bool HitFanCircle(
        const VECTOR& origin, const VECTOR& forward, float radius, float halfAngleRad,
        const VECTOR& target, float targetRadius);
}