#include "../../../../Audio/AudioManager.h"
#include "../../../Common/AnimationController/AnimationController.h"
#include "../Action/BossAttackAction.h"
#include "../Boss.h"

#include "BossAttackState.h"

void BossAttackState::Enter(Boss& owner)
{
    // �����E�U���A�j���Đ��E����̏���
   owner.StartAttack();
   action_ = owner.GetCurrentAction();

   // ���߂̊Ԃ����A�j���̑�����ύX
   const AttackParam& param = owner.GetCurrentAttackParam();
   owner.GetAnimationController()->ChangeSpeedForFrame(param.windupAnimRate, param.windupFrame);

   action_->OnWindupStart(owner);
   ChangePhase(ATTACK_PHASE::WINDUP);
}

BOSS_STATE BossAttackState::Update(Boss& owner)
{
	phaseFrame_++;

	switch (phase_)
	{
	case ATTACK_PHASE::WINDUP:
		UpdateWindup(owner);
		return BOSS_STATE::NONE;

	case ATTACK_PHASE::ACTIVE:
		UpdateActive(owner);
		return BOSS_STATE::NONE;

	default:
		return UpdateRecovery(owner);
	}
}

void BossAttackState::Exit(Boss& owner)
{
    owner.EndAttack();
}

void BossAttackState::UpdateWindup(Boss& owner)
{
	action_->UpdateWindup(owner);
	// ���߂��I����Ă��Ȃ���Α҂�

	if (phaseFrame_ < owner.GetCurrentAttackParam().windupFrame) return;

	// �U���{�̂�
	owner.SetAttackActive(true);
	action_->OnActiveStart(owner);
	ChangePhase(ATTACK_PHASE::ACTIVE);
}

void BossAttackState::UpdateActive(Boss& owner)
{
	// �U���{�̂��I����Ă��Ȃ���Α�����
	if (!action_->UpdateActive(owner)) return;

	// ����
	owner.SetAttackActive(false);
	owner.EndAttack();
	owner.GetAnimationController()->Play(static_cast<int>(Boss::ANIM_TYPE::IDLE));
	ChangePhase(ATTACK_PHASE::RECOVERY);
}

BOSS_STATE BossAttackState::UpdateRecovery(Boss& owner)
{
	// �����I����Ă��Ȃ���Α҂�
	if (phaseFrame_ < owner.GetCurrentAttackParam().recoveryFrame) return BOSS_STATE::NONE;

	return BOSS_STATE::IDLE;
}

void BossAttackState::ChangePhase(ATTACK_PHASE nextPhase)
{
	phase_ = nextPhase;
	phaseFrame_ = 0;

	if (phase_ == ATTACK_PHASE::WINDUP)
	{
		AudioManager::GetInstance()->PlaySE(action_->GetSignSoundID());
		return;
	}

	if (phase_ == ATTACK_PHASE::ACTIVE)
	{
		AudioManager::GetInstance()->PlaySE(action_->GetAttackSoundID());
		return;
	}

}