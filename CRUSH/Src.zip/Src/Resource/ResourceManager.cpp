#include <DxLib.h>
#include "../Application.h"

#include "ResourceManager.h"

ResourceManager* ResourceManager::instance_ = nullptr;

ResourceManager::ResourceManager(void)
{
}

ResourceManager::~ResourceManager(void)
{
	// �ǂݍ��񂾂��̂�������Ă���A�o�^������
	Release();

	for (auto& [src, res] : resources_)
	{
		delete res;
	}
	resources_.clear();
}

void ResourceManager::Init(void)
{
	// �v���C���[���f��
	Register(SRC::PLAYER, Resource::TYPE::MODEL, Application::PATH_MODEL + "Player/Warrior.mv1");

	// �v���C���[�̌����f��
	Register(SRC::PLAYER_SWORD, Resource::TYPE::MODEL, Application::PATH_MODEL + "Player/sword.mv1");

	// �v���C���[�̃A�j���[�V����
	Register(SRC::PLAYER_ANIM_IDLE, Resource::TYPE::MODEL, Application::PATH_MODEL + "Player/Idle.mv1");
	Register(SRC::PLAYER_ANIM_WALK, Resource::TYPE::MODEL, Application::PATH_MODEL + "Player/Walk.mv1");
	Register(SRC::PLAYER_ANIM_RUN, Resource::TYPE::MODEL, Application::PATH_MODEL + "Player/Run.mv1");
	Register(SRC::PLAYER_ANIM_ATTACK_1, Resource::TYPE::MODEL, Application::PATH_MODEL + "Player/Attack1.mv1");
	Register(SRC::PLAYER_ANIM_ROLL, Resource::TYPE::MODEL, Application::PATH_MODEL + "Player/Roll.mv1");
	Register(SRC::PLAYER_ANIM_HIT, Resource::TYPE::MODEL, Application::PATH_MODEL + "Player/Hit.mv1");
	Register(SRC::PLAYER_ANIM_DEATH, Resource::TYPE::MODEL, Application::PATH_MODEL + "Player/Death.mv1");

	// �{�X���f��
	Register(SRC::BOSS, Resource::TYPE::MODEL, Application::PATH_MODEL + "Boss/Dragon.mv1");

	// �X�e�[�W���f��
	Register(SRC::STAGE, Resource::TYPE::MODEL, Application::PATH_MODEL + "Stage/Stage.mv1");

	// �^�C�g�����S
	Register(SRC::TITLE_LOGO, Resource::TYPE::IMG, Application::PATH_IMAGE + "CRUSHLOGO.png");
}

void ResourceManager::Release(void)
{
	for (auto& [src, res] : resources_)
	{
		res->Release();
	}
}

const Resource& ResourceManager::Load(SRC src)
{
	Resource* res = Find(src);

	// �o�^����Ă��Ȃ�
	if (res == nullptr) return dummy_;

	res->Load();
	return *res;
}

int ResourceManager::LoadModelDuplicate(SRC src)
{
	Resource* res = Find(src);

	// �o�^����Ă��Ȃ�
	if (res == nullptr) return -1;

	res->Load();
	return res->DuplicateModel();
}

void ResourceManager::Register(SRC src, Resource::TYPE type, const std::string& path)
{
	// �������O��2��o�^���Ȃ�
	if (Find(src) != nullptr) return;

	resources_.emplace(src, new Resource(type, path));
}

Resource* ResourceManager::Find(SRC src) const
{
	const auto it = resources_.find(src);

	// ������Ȃ�
	if (it == resources_.end()) return nullptr;

	return it->second;
}